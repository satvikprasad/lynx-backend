--require("plugins.blue_strobe")
--require("plugins.triangle")
require("plugins.waveform")

O = lynx.opt

O.bg_color = {1, 1, 25, 255}

